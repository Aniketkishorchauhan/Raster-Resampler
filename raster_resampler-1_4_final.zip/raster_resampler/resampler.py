"""
resampler.py
GDAL-native + custom NumPy/SciPy resampling.
Now also handles: target CRS reprojection, clip by extent, clip by shapefile.
"""

import numpy as np
from osgeo import gdal


# ── GDAL method map ────────────────────────────────────────────────────────────
def _safe(attr, fallback):
    return getattr(gdal, attr, fallback)

GDAL_METHOD_MAP = {
    'near':         gdal.GRA_NearestNeighbour,
    'bilinear':     gdal.GRA_Bilinear,
    'cubic':        gdal.GRA_Cubic,
    'cubicspline':  gdal.GRA_CubicSpline,
    'lanczos':      gdal.GRA_Lanczos,
    'average':      gdal.GRA_Average,
    'rms':          _safe('GRA_RMS',  gdal.GRA_Average),
    'mode':         gdal.GRA_Mode,
    'max':          _safe('GRA_Max',  gdal.GRA_NearestNeighbour),
    'min':          _safe('GRA_Min',  gdal.GRA_NearestNeighbour),
    'med':          _safe('GRA_Med',  gdal.GRA_Average),
    'q1':           _safe('GRA_Q1',   gdal.GRA_Average),
    'q3':           _safe('GRA_Q3',   gdal.GRA_Average),
    'sum':          _safe('GRA_Sum',  gdal.GRA_Average),
}

CUSTOM_METHODS = {'gaussian', 'spline', 'morph_dilation', 'morph_erosion'}


# ── Helpers ────────────────────────────────────────────────────────────────────

def get_raster_info(path):
    """
    Return dict with keys: x_res, y_res, width, height, crs_wkt, band_count.
    Raises ValueError if file cannot be opened.
    """
    ds = gdal.Open(path)
    if ds is None:
        raise ValueError(f"Cannot open: {path}")
    gt = ds.GetGeoTransform()
    info = {
        'x_res':      abs(gt[1]),
        'y_res':      abs(gt[5]),
        'width':      ds.RasterXSize,
        'height':     ds.RasterYSize,
        'crs_wkt':    ds.GetProjection(),
        'band_count': ds.RasterCount,
    }
    ds = None
    return info


def get_resolution_from_file(path):
    info = get_raster_info(path)
    return info['x_res'], info['y_res']


def _write_geotiff(output_path, arrays, geotransform, projection, dtype, nodata=None):
    rows, cols = arrays[0].shape
    driver = gdal.GetDriverByName('GTiff')
    ds_out = driver.Create(
        output_path, cols, rows, len(arrays), dtype,
        options=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=IF_SAFER']
    )
    ds_out.SetGeoTransform(geotransform)
    ds_out.SetProjection(projection)
    for i, arr in enumerate(arrays, start=1):
        band = ds_out.GetRasterBand(i)
        if nodata is not None:
            band.SetNoDataValue(nodata)
        band.WriteArray(arr)
    ds_out.FlushCache()
    ds_out = None


# ── Custom SciPy methods ───────────────────────────────────────────────────────

def _apply_custom(arr, zoom_y, zoom_x, method_code, nodata_val):
    from scipy.ndimage import zoom as spzoom
    if nodata_val is not None:
        arr = arr.copy()
        arr[arr == nodata_val] = np.nan
    clean = np.nan_to_num(arr, nan=0.0)

    if method_code == 'gaussian':
        from scipy.ndimage import gaussian_filter
        sigma = max(0.5, 0.5 / min(zoom_x, zoom_y)) if min(zoom_x, zoom_y) < 1 else 0.5
        out = spzoom(gaussian_filter(clean, sigma=sigma), (zoom_y, zoom_x), order=1)
    elif method_code == 'spline':
        out = spzoom(clean, (zoom_y, zoom_x), order=3)
    elif method_code == 'morph_dilation':
        from scipy.ndimage import maximum_filter
        factor = max(1, int(round(1.0 / min(zoom_x, zoom_y))))
        out = spzoom(maximum_filter(clean, size=max(3, factor * 2 + 1)),
                     (zoom_y, zoom_x), order=0)
    elif method_code == 'morph_erosion':
        from scipy.ndimage import minimum_filter
        factor = max(1, int(round(1.0 / min(zoom_x, zoom_y))))
        out = spzoom(minimum_filter(clean, size=max(3, factor * 2 + 1)),
                     (zoom_y, zoom_x), order=0)
    else:
        raise ValueError(f"Unknown custom method: {method_code}")

    if nodata_val is not None:
        out[np.isnan(out)] = nodata_val
    return out


def resample_raster_custom(input_path, output_path, x_res, y_res, method_code, nodata=None):
    """Custom SciPy resampling — does NOT support CRS/clip (use GDAL path for those)."""
    ds = gdal.Open(input_path)
    if ds is None:
        raise ValueError(f"Cannot open: {input_path}")
    gt       = list(ds.GetGeoTransform())
    proj     = ds.GetProjection()
    zoom_x   = abs(gt[1]) / x_res
    zoom_y   = abs(gt[5]) / y_res
    dtype    = ds.GetRasterBand(1).DataType
    out_arrs = []
    for b in range(1, ds.RasterCount + 1):
        band = ds.GetRasterBand(b)
        arr  = band.ReadAsArray().astype(np.float64)
        nd   = nodata if nodata is not None else band.GetNoDataValue()
        out_arrs.append(_apply_custom(arr, zoom_y, zoom_x, method_code, nd))
    ds = None
    gt[1] =  x_res
    gt[5] = -y_res
    _write_geotiff(output_path, out_arrs, tuple(gt), proj, dtype, nodata)


# ── Public entry point ─────────────────────────────────────────────────────────

def resample_raster(input_path, output_path, x_res, y_res,
                    method_code, nodata=None,
                    target_crs=None,
                    clip_extent=None,
                    clip_shapefile=None):
    """
    Parameters
    ----------
    input_path     : str
    output_path    : str
    x_res / y_res  : float  target pixel size in map units
    method_code    : str    see GDAL_METHOD_MAP or CUSTOM_METHODS
    nodata         : float | None
    target_crs     : str | None   e.g. 'EPSG:4326'  — reproject output
    clip_extent    : tuple | None  (xmin, ymin, xmax, ymax) in target CRS
    clip_shapefile : str | None   path to .shp used as cutline
    """
    if method_code in CUSTOM_METHODS:
        # SciPy path — CRS/clip not supported here; fall back to GDAL near if needed
        resample_raster_custom(input_path, output_path,
                               x_res, y_res, method_code, nodata)
        return

    alg  = GDAL_METHOD_MAP.get(method_code, gdal.GRA_NearestNeighbour)
    opts = dict(
        format='GTiff',
        xRes=x_res,
        yRes=y_res,
        resampleAlg=alg,
        creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=IF_SAFER'],
    )

    if nodata is not None:
        opts['srcNodata'] = nodata
        opts['dstNodata'] = nodata

    if target_crs:
        opts['dstSRS'] = target_crs

    if clip_extent:
        xmin, ymin, xmax, ymax = clip_extent
        opts['outputBounds'] = (xmin, ymin, xmax, ymax)

    if clip_shapefile and clip_shapefile.strip():
        opts['cutlineDSName']  = clip_shapefile
        opts['cropToCutline']  = True

    result = gdal.Warp(output_path, input_path, **opts)
    if result is None:
        raise RuntimeError(f"gdal.Warp failed for: {input_path}")
    result.FlushCache()
    result = None
