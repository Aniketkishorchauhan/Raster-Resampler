import os
from osgeo import gdal

SUPPORTED_EXTENSIONS = {'.tif', '.tiff', '.img', '.vrt', '.nc'}


def scan_folder(folder_path):
    """Return all supported raster files directly inside folder (non-recursive)."""
    files = []
    for f in sorted(os.listdir(folder_path)):
        if os.path.splitext(f)[1].lower() in SUPPORTED_EXTENSIONS:
            files.append(os.path.join(folder_path, f))
    return files


def validate_files(file_paths):
    """
    Check each path is a readable raster.

    Returns
    -------
    valid   : list[str]
    invalid : list[tuple(str, str)]  – (path, reason)
    """
    valid, invalid = [], []
    for path in file_paths:
        if not os.path.exists(path):
            invalid.append((path, "File not found"))
            continue
        ext = os.path.splitext(path)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            invalid.append((path, f"Unsupported extension: {ext}"))
            continue
        ds = gdal.Open(path)
        if ds is None:
            invalid.append((path, "GDAL cannot open file"))
            continue
        ds = None
        valid.append(path)
    return valid, invalid


def generate_output_path(input_path, output_folder, suffix):
    """Build output path: <output_folder>/<basename><suffix>.tif"""
    basename = os.path.splitext(os.path.basename(input_path))[0]
    return os.path.join(output_folder, f"{basename}{suffix}.tif")
