def classFactory(iface):
    from .plugin import RasterResamplerPlugin
    return RasterResamplerPlugin(iface)
