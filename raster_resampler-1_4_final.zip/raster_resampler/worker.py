import os
from qgis.PyQt.QtCore import QObject, pyqtSignal

from .resampler import resample_raster, get_resolution_from_file
from .batch_handler import generate_output_path, validate_files


class ResampleWorker(QObject):
    progress  = pyqtSignal(int, str)
    file_done = pyqtSignal(str)
    finished  = pyqtSignal(list)
    error     = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self.params   = params
        self._running = True

    def stop(self):
        self._running = False

    def run(self):
        try:
            p = self.params

            if p['use_ref']:
                x_res, y_res = get_resolution_from_file(p['ref_path'])
            else:
                x_res = y_res = p['resolution']

            valid, invalid = validate_files(p['files'])
            if invalid:
                names = '\n'.join(
                    f"  {os.path.basename(path)}: {reason}"
                    for path, reason in invalid)
                self.error.emit(
                    f"Skipped {len(invalid)} invalid file(s):\n{names}")
                if not valid:
                    return

            os.makedirs(p['output_folder'], exist_ok=True)

            total        = len(valid)
            output_paths = []

            for i, input_path in enumerate(valid):
                if not self._running:
                    break

                fname = os.path.basename(input_path)
                pct   = int((i / total) * 100)
                self.progress.emit(pct, f"Processing {i+1}/{total}: {fname}")

                output_path = generate_output_path(
                    input_path, p['output_folder'], p['suffix'])

                resample_raster(
                    input_path      = input_path,
                    output_path     = output_path,
                    x_res           = x_res,
                    y_res           = y_res,
                    method_code     = p['method'],
                    nodata          = p.get('nodata'),
                    target_crs      = p.get('target_crs'),
                    clip_extent     = p.get('clip_extent'),
                    clip_shapefile  = p.get('clip_shapefile'),
                )

                output_paths.append(output_path)
                self.file_done.emit(output_path)

            self.finished.emit(output_paths)

        except Exception as e:
            self.error.emit(str(e))
