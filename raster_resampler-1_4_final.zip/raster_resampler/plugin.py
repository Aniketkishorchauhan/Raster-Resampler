import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon


class RasterResamplerPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icons', 'icon.png')
        self.action = QAction(QIcon(icon_path), 'Raster Resampler', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu('Raster Resampler', self.action)

    def unload(self):
        self.iface.removePluginRasterMenu('Raster Resampler', self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        from .dialog import RasterResamplerDialog
        if self.dialog is None:
            self.dialog = RasterResamplerDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
