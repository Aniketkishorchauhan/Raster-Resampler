"""
dialog.py  —  Raster Resampler
New in this version:
  • Auto-detects source raster resolution on file select
  • Shows current res, auto-suggests Upscaling / Downscaling direction
  • CRS Converter section (QgsProjectionSelectionWidget or EPSG text fallback)
  • Clip section — by extent (4 coords + Use Canvas Extent) or by shapefile
  • PyQt5 / PyQt6 compatible shim
"""

import os
import glob
import tempfile

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QLineEdit, QComboBox,
    QRadioButton, QGroupBox, QCheckBox, QProgressBar,
    QFileDialog, QListWidget, QListWidgetItem,
    QDoubleSpinBox, QAbstractItemView, QWidget,
    QMessageBox, QTabWidget, QTableWidget,
    QTableWidgetItem, QHeaderView, QFrame,
    QScrollArea,
)
from qgis.PyQt.QtCore import Qt, QThread
from qgis.PyQt.QtGui import QColor
from osgeo import gdal


# ── PyQt5 / PyQt6 compatibility ───────────────────────────────────────────────
try:
    _Qt_Minimize        = Qt.WindowType.WindowMinimizeButtonHint
    _Qt_ScrollAsNeeded  = Qt.ScrollBarPolicy.ScrollBarAsNeeded
    _Qt_ItemSelectable  = Qt.ItemFlag.ItemIsSelectable
    _Qt_ItemEnabled     = Qt.ItemFlag.ItemIsEnabled
    _Qt_AlignCenter     = Qt.AlignmentFlag.AlignCenter
    _Qt_AlignRight      = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
    _Qt_RichText        = Qt.TextFormat.RichText
    _QAV_ExtendedSel    = QAbstractItemView.SelectionMode.ExtendedSelection
    _QAV_SelectRows     = QAbstractItemView.SelectionBehavior.SelectRows
    _QAV_NoEdit         = QAbstractItemView.EditTrigger.NoEditTriggers
    _QHV_ResizeContents = QHeaderView.ResizeMode.ResizeToContents
    _QFrame_NoFrame     = QFrame.Shape.NoFrame
    _QFrame_HLine       = QFrame.Shape.HLine
    _QFrame_VLine       = QFrame.Shape.VLine
except AttributeError:
    _Qt_Minimize        = Qt.WindowMinimizeButtonHint
    _Qt_ScrollAsNeeded  = Qt.ScrollBarAsNeeded
    _Qt_ItemSelectable  = Qt.ItemIsSelectable
    _Qt_ItemEnabled     = Qt.ItemIsEnabled
    _Qt_AlignCenter     = Qt.AlignCenter
    _Qt_AlignRight      = Qt.AlignRight | Qt.AlignVCenter
    _Qt_RichText        = Qt.RichText
    _QAV_ExtendedSel    = QAbstractItemView.ExtendedSelection
    _QAV_SelectRows     = QAbstractItemView.SelectRows
    _QAV_NoEdit         = QAbstractItemView.NoEditTriggers
    _QHV_ResizeContents = QHeaderView.ResizeToContents
    _QFrame_NoFrame     = QFrame.NoFrame
    _QFrame_HLine       = QFrame.HLine
    _QFrame_VLine       = QFrame.VLine


# ── CRS widget — use native QGIS picker if available ─────────────────────────
try:
    from qgis.gui import QgsProjectionSelectionWidget
    _HAS_CRS_WIDGET = True
except ImportError:
    _HAS_CRS_WIDGET = False

try:
    from qgis.core import QgsCoordinateReferenceSystem
    _HAS_CRS_CORE = True
except ImportError:
    _HAS_CRS_CORE = False


# ── Resolution units ──────────────────────────────────────────────────────────
UNIT_OPTIONS = [
    ("m  — metres",      "m",   1.0),
    ("km — kilometres",  "km",  1000.0),
    ("cm — centimetres", "cm",  0.01),
    ("°  — degrees",     "deg", 1.0),
]


# ── Resampling method catalogue ───────────────────────────────────────────────
RESAMPLING_METHODS = [
    ("Nearest Neighbour",      "near",          "GDAL",  "both",
     "Copies the value of the closest source pixel. No interpolation. "
     "Best for categorical / classified rasters (land cover, masks)."),
    ("Gaussian Filter",        "gaussian",      "SciPy", "both",
     "Gaussian blur scaled to the zoom factor before resampling. "
     "Smooths high-frequency noise. Suitable for both directions."),
    # Downscaling
    ("Bilinear Interpolation", "bilinear",      "GDAL",  "down",
     "Weighted average of 4 nearest pixels. Smooth output. Standard for continuous coarse→fine."),
    ("Cubic Convolution",      "cubic",         "GDAL",  "down",
     "Weighted average over 16 pixels. Sharper edges than bilinear. Good for optical imagery."),
    ("Cubic Spline",           "cubicspline",   "GDAL",  "down",
     "Very smooth spline over 16 pixels. Best for DEMs and continuous surfaces."),
    ("Lanczos",                "lanczos",       "GDAL",  "down",
     "Sinc filter over 6×6 window. Sharpest interpolation result."),
    ("Spline Interpolation",   "spline",        "SciPy", "down",
     "3rd-order spline zoom. Smooth, continuous surface for DEMs and terrain."),
    # Upscaling
    ("Mean Aggregation",       "average",       "GDAL",  "up",
     "Arithmetic mean of source pixels. Reduces noise. Best for continuous imagery fine→coarse."),
    ("Median Aggregation",     "med",           "GDAL",  "up",
     "Middle value. Robust to outliers during aggregation."),
    ("Maximum Aggregation",    "max",           "GDAL",  "up",
     "Highest contributing value. Preserves peak signals. Good for flood extent."),
    ("Minimum Aggregation",    "min",           "GDAL",  "up",
     "Lowest contributing value. Preserves minima. Good for drought/shadow."),
    ("Mode / Majority Rule",   "mode",          "GDAL",  "up",
     "Most frequent value. Best for categorical rasters during aggregation."),
    ("RMS Aggregation",        "rms",           "GDAL",  "up",
     "Root mean square. More sensitive to strong values. Useful for SAR."),
    ("Q1 — 25th Percentile",   "q1",            "GDAL",  "up",
     "25th percentile. Biased toward lower values."),
    ("Q3 — 75th Percentile",   "q3",            "GDAL",  "up",
     "75th percentile. Biased toward higher values."),
    ("Sum Aggregation",        "sum",           "GDAL",  "up",
     "Sum of all contributing pixels. Use for counts / cumulative quantities."),
    ("Morphological Dilation", "morph_dilation","SciPy", "up",
     "Maximum filter before resizing. Expands bright regions."),
    ("Morphological Erosion",  "morph_erosion", "SciPy", "up",
     "Minimum filter before resizing. Shrinks bright regions."),
]

RASTER_FILTER   = "Raster Files (*.tif *.tiff *.img *.vrt *.nc);;All Files (*)"
SHAPEFILE_FILTER = "Shapefiles (*.shp);;All Files (*)"


# ── 44-method reference table ─────────────────────────────────────────────────
ALL_METHODS_REFERENCE = [
    ("Upscaling",   "Mean Aggregation",              "Statistical",      "Average of source pixels",                      "Continuous data",         "Simple, stable",                    "Smooths extremes",                      True),
    ("Upscaling",   "Median Aggregation",            "Statistical",      "Middle value of source pixels",                 "Noisy data",              "Robust to outliers",                "Loses extremes",                        True),
    ("Upscaling",   "Maximum Aggregation",           "Extreme-based",    "Highest value among pixels",                    "Floods, hotspots",        "Preserves peaks",                   "Sensitive to noise",                    True),
    ("Upscaling",   "Minimum Aggregation",           "Extreme-based",    "Lowest value among pixels",                     "Drought analysis",        "Preserves minima",                  "Ignores variability",                   True),
    ("Upscaling",   "Majority Rule (MRB)",           "Frequency-based",  "Most frequent value",                           "Categorical rasters",     "Preserves dominant class",          "Abrupt transitions",                    True),
    ("Upscaling",   "Weighted Aggregation",          "Weighted",         "Weighted avg by external weight raster",        "Sensor fusion",           "Flexible",                          "Requires weight raster",                False),
    ("Upscaling",   "Bilinear Aggregation",          "Interpolation",    "Distance-weighted 4-neighbour average",         "Continuous surfaces",     "Smooth output",                     "Boundary blurring",                     True),
    ("Upscaling",   "Gaussian Aggregation",          "Filter-based",     "Gaussian neighbourhood weighting",              "Noise reduction",         "Smooth filtering",                  "Oversmoothing at large sigma",          True),
    ("Upscaling",   "Adaptive Aggregation",          "Adaptive",         "Rules adapt to local image conditions",         "Heterogeneous regions",   "Preserves variability",             "Complex implementation",                False),
    ("Upscaling",   "Object-Based Aggregation",      "Object-based",     "Average within image segments",                 "Urban mapping",           "Shape-aware",                       "Needs segmentation step",               False),
    ("Upscaling",   "Fuzzy Aggregation",             "Fuzzy logic",      "Membership-weighted aggregation",               "Mixed pixels",            "Handles uncertainty",               "Complex interpretation",                False),
    ("Upscaling",   "Entropy-Based Aggregation",     "Information",      "Weight by information content",                 "Texture analysis",        "Preserves heterogeneity",           "High computation",                      False),
    ("Upscaling",   "Morphological Aggregation",     "Morphological",    "Dilation or erosion before resize",             "Shape preservation",      "Retains structure",                 "May distort values",                    True),
    ("Upscaling",   "Wavelet-Based Upscaling",       "Freq-domain",      "Multi-resolution DWT decomposition",            "Image processing",        "Multi-scale detail",                "Needs PyWavelets library",              False),
    ("Upscaling",   "Geostatistical Aggregation",    "Spatial stats",    "Variogram-informed aggregation",                "Environmental modelling", "Spatially robust",                  "Requires variogram fitting",            False),
    ("Upscaling",   "Fractal Aggregation",           "Fractal",          "Scale-invariant self-similarity",               "Terrain / ecology",       "Multi-scale realism",               "Difficult calibration",                 False),
    ("Upscaling",   "Sub-Pixel Aggregation",         "Mixed-pixel",      "Fractional pixel composition tracking",         "Land cover mixing",       "Better mixed-pixel handling",       "Complex implementation",                False),
    ("Upscaling",   "Adaptive Majority Aggregation", "Adaptive freq",    "Frequency similarity + weighted average",       "Transition zones",        "Reduces modal instability",         "Requires discretized data",             False),
    ("Downscaling", "Nearest Neighbour",             "Interpolation",    "Closest pixel assignment",                      "Classified rasters",      "Fast, exact values",                "Blocky appearance",                     True),
    ("Downscaling", "Bilinear Interpolation",        "Interpolation",    "Weighted 4-neighbour average",                  "Continuous data",         "Smooth transitions",                "Blurred edges",                         True),
    ("Downscaling", "Cubic Convolution",             "Interpolation",    "16-pixel cubic polynomial",                     "Satellite imagery",       "High visual quality",               "Computationally heavier",               True),
    ("Downscaling", "Bicubic Interpolation",         "Interpolation",    "Cubic surface fitting",                         "Image enhancement",       "Smooth output",                     "Can oversmooth",                        True),
    ("Downscaling", "Spline Interpolation",          "Mathematical",     "Smooth spline between pixel values",            "DEMs, terrain",           "Smooth continuous surface",         "Ringing artifacts possible",            True),
    ("Downscaling", "Kriging",                       "Geostatistical",   "Optimal interpolation via autocorrelation",     "Environmental vars",      "High accuracy",                     "Needs variogram + auxiliary data",      False),
    ("Downscaling", "Co-Kriging",                    "Geostatistical",   "Multi-variable kriging with covariate",         "Soil moisture, climate",  "Uses auxiliary info",               "Complex modelling",                     False),
    ("Downscaling", "Regression-Based",              "Statistical",      "Statistical regression on predictors",          "Climate, rainfall",       "Simple interpretation",             "Linear + needs predictors",             False),
    ("Downscaling", "Regression Kriging",            "Hybrid",           "Regression residuals corrected by kriging",     "Environmental mapping",   "High precision",                    "Computationally complex",               False),
    ("Downscaling", "Statistical Downscaling",       "Statistical",      "Predictor-predictand transfer functions",       "Climate studies",         "Widely used",                       "Requires calibration dataset",          False),
    ("Downscaling", "Dynamical Downscaling",         "Physical model",   "Regional climate model simulation",             "Weather / climate",       "Physically realistic",              "Extremely expensive",                   False),
    ("Downscaling", "Machine Learning",              "AI / ML",          "ML model on coarse-fine training pairs",        "Soil moisture, rainfall", "Captures nonlinear patterns",       "Needs labelled training data",          False),
    ("Downscaling", "Deep Learning (CNN/GAN)",       "Deep learning",    "CNN / GAN / U-Net super-resolution",            "Super-resolution",        "High-detail prediction",            "Needs GPU and large dataset",           False),
    ("Downscaling", "Thermal Sharpening",            "Thermal fusion",   "Optical-thermal statistical relationship",      "LST downscaling",         "Good thermal detail",               "Needs optical + thermal band pair",     False),
    ("Downscaling", "Bayesian Downscaling",          "Probabilistic",    "Bayesian inference with priors",                "Uncertainty analysis",    "Quantifies uncertainty",            "Complex probabilistic framework",       False),
    ("Downscaling", "Wavelet-Based Downscaling",     "Freq-domain",      "Multi-scale wavelet decomposition",             "Image enhancement",       "Preserves multi-scale detail",      "Needs PyWavelets library",              False),
    ("Downscaling", "Fractal Downscaling",           "Fractal",          "Scale invariance and self-similarity",          "Terrain / climate",       "Multi-scale realism",               "Difficult validation",                  False),
    ("Downscaling", "Topographic Downscaling",       "Terrain-based",    "Elevation / slope / aspect regression",         "Mountain climate",        "Terrain-aware",                     "Needs DEM as secondary input",          False),
    ("Downscaling", "Vegetation-Based",              "Biophysical",      "NDVI / LAI statistical relationships",          "Soil moisture",           "Vegetation-sensitive",              "Seasonal, needs NDVI input",            False),
    ("Downscaling", "Data Fusion",                   "Multi-sensor",     "Combine coarse + fine sensor imagery",          "MODIS-Landsat fusion",    "Better spatial/temporal detail",    "Sensor mismatch issues",                False),
    ("Downscaling", "Super-Resolution Mapping",      "Sub-pixel",        "Recover fine spatial patterns",                 "Remote sensing",          "High-detail output",                "Computationally intensive",             False),
    ("Downscaling", "Sparse Representation",         "Signal proc.",     "Sparse coding / compressed sensing",            "Super-resolution",        "Efficient representation",          "Complex dictionary learning",           False),
    ("Downscaling", "Hybrid Downscaling",            "Hybrid",           "Combines multiple approaches adaptively",       "Advanced applications",   "Better robustness",                 "Very complex",                          False),
    ("Downscaling", "RMS Aggregation",               "Statistical",      "Root mean square of contributing pixels",       "Radar / SAR data",        "Amplifies strong signals",          "Sensitive to extremes",                 True),
    ("Downscaling", "Sum Aggregation",               "Statistical",      "Sum of all contributing pixels",                "Rainfall, counts",        "Preserves cumulative quantities",   "Only for additive data",                True),
    ("Downscaling", "Lanczos",                       "Interpolation",    "Sinc filter over 6x6 window",                   "High-quality imagery",    "Sharpest interpolation result",     "Slow on large datasets",                True),
]


# ── Browse button factory ─────────────────────────────────────────────────────
def _browse_btn(label="Browse"):
    btn = QPushButton(label)
    btn.setStyleSheet(
        "QPushButton { background-color:#455A64 !important; color:#ECEFF1 !important;"
        " border:1px solid #78909C !important; border-radius:3px !important;"
        " padding:4px 12px !important; min-width:65px !important; font-weight:bold !important; }"
        "QPushButton:hover   { background-color:#546E7A !important; }"
        "QPushButton:pressed { background-color:#263238 !important; }"
    )
    btn.setFixedHeight(26)
    return btn


# ── Full stylesheet ───────────────────────────────────────────────────────────
FULL_STYLE = """
QDialog, QWidget { background-color:#2b2b2b; color:#e0e0e0; font-size:13px; }
QGroupBox {
    font-weight:bold; font-size:13px;
    border:1px solid #505050; border-radius:5px;
    margin-top:10px; padding-top:8px; color:#cccccc;
}
QGroupBox::title { subcontrol-origin:margin; left:10px; padding:0 4px; color:#cccccc; }
QLabel     { color:#e0e0e0; }
QRadioButton { color:#e0e0e0; spacing:6px; }
QCheckBox    { color:#e0e0e0; spacing:6px; }
QLineEdit {
    background:#3c3f41; border:1px solid #666;
    border-radius:3px; padding:4px 6px; color:#ffffff;
}
QLineEdit:focus { border:1px solid #1E88E5; }
QComboBox {
    background:#3c3f41; border:1px solid #666;
    border-radius:3px; padding:4px 8px; color:#ffffff; min-height:22px;
}
QComboBox::drop-down { width:24px; border-left:1px solid #555; border-radius:0 3px 3px 0; background:#3c3f41; }
QComboBox::down-arrow { image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6'><polygon points='0,0 10,0 5,6' fill='%23cccccc'/></svg>"); width:10px; height:6px; }
QComboBox QAbstractItemView {
    background-color:#3c3f41; color:#ffffff;
    selection-background-color:#1565C0; selection-color:#ffffff;
    border:1px solid #666; outline:none;
}
QComboBox QAbstractItemView::item { color:#ffffff; padding:4px 8px; min-height:22px; }
QComboBox QAbstractItemView::item:selected { background-color:#1565C0; color:#ffffff; }
QComboBox QAbstractItemView::item:disabled { color:#888; }
QDoubleSpinBox {
    background:#3c3f41; border:1px solid #666;
    border-radius:3px; padding:4px 6px; color:#ffffff;
}
QListWidget { background:#3c3f41; border:1px solid #666; border-radius:3px; color:#ffffff; }
QListWidget::item:selected { background:#1565C0; color:white; }
QTableWidget { background:#2b2b2b; color:#e0e0e0; gridline-color:#444; alternate-background-color:#323232; }
QTableWidget::item { color:#e0e0e0; padding:3px 6px; }
QTableWidget::item:selected { background:#1565C0; color:white; }
QHeaderView::section { background:#3c3f41; color:#e0e0e0; font-weight:bold; padding:5px 6px; border:1px solid #505050; }
QProgressBar { border:1px solid #555; border-radius:3px; text-align:center; color:#fff; background:#3c3f41; min-height:18px; }
QProgressBar::chunk { background:#1565C0; border-radius:2px; }
QScrollBar:vertical   { background:#2b2b2b; width:12px; }
QScrollBar::handle:vertical { background:#555; border-radius:5px; min-height:20px; }
QScrollBar::handle:vertical:hover { background:#777; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QScrollBar:horizontal { background:#2b2b2b; height:12px; }
QScrollBar::handle:horizontal { background:#555; border-radius:5px; min-width:20px; }
QScrollBar::handle:horizontal:hover { background:#777; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width:0; }
QTabWidget::pane { border:1px solid #505050; }
QTabBar::tab { background:#3c3f41; color:#bbb; padding:6px 18px; border:1px solid #555; border-bottom:none; border-radius:3px 3px 0 0; }
QTabBar::tab:selected { background:#1565C0; color:white; font-weight:bold; }
QTabBar::tab:hover:!selected { background:#4a4a4a; }
"""


class RasterResamplerDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface            = iface
        self.worker           = None
        self.thread           = None
        self._source_x_res    = None   # detected from loaded file
        self._source_y_res    = None
        self._prev_unit_idx   = 0      # tracks last selected unit for auto-conversion

        self.setWindowTitle("Raster Resampler")
        self.setMinimumWidth(740)
        self.setMinimumHeight(700)
        self.resize(760, 860)
        self.setWindowFlags(self.windowFlags() | _Qt_Minimize)
        self.setStyleSheet(FULL_STYLE)

        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(0)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_resampler_tab(), "  Resampler  ")
        self.tabs.addTab(self._build_reference_tab(), "  Methods Reference  ")
        root.addWidget(self.tabs)
        self._style_action_buttons()

    # =========================================================================
    # TAB 1 — Resampler
    # =========================================================================

    def _build_resampler_tab(self):
        content = QWidget()
        lay = QVBoxLayout(content)
        lay.setSpacing(8)
        lay.setContentsMargins(10, 10, 10, 10)

        lay.addWidget(self._build_mode_group())
        lay.addWidget(self._build_input_group())
        lay.addWidget(self._build_resolution_group())
        lay.addWidget(self._build_operation_group())
        lay.addWidget(self._build_nodata_group())
        lay.addWidget(self._build_crs_group())
        lay.addWidget(self._build_clip_group())
        lay.addWidget(self._build_output_group())
        lay.addWidget(self._build_progress_group())
        lay.addLayout(self._build_button_row())
        lay.addStretch()

        scroll = QScrollArea()
        scroll.setWidget(content)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(_QFrame_NoFrame)
        scroll.setHorizontalScrollBarPolicy(_Qt_ScrollAsNeeded)
        scroll.setVerticalScrollBarPolicy(_Qt_ScrollAsNeeded)
        return scroll

    # ── Mode ──────────────────────────────────────────────────────────────────
    def _build_mode_group(self):
        grp = QGroupBox("Processing Mode")
        lay = QHBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        self.rb_single = QRadioButton("Single File")
        self.rb_batch  = QRadioButton("Batch (Multiple Files)")
        self.rb_single.setChecked(True)
        self.rb_single.toggled.connect(self._toggle_mode)
        lay.addWidget(self.rb_single)
        lay.addSpacing(30)
        lay.addWidget(self.rb_batch)
        lay.addStretch()
        return grp

    # ── Input ─────────────────────────────────────────────────────────────────
    def _build_input_group(self):
        grp = QGroupBox("Input")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(6)

        # Single file
        self.single_widget = QWidget()
        sr = QHBoxLayout(self.single_widget)
        sr.setContentsMargins(0, 0, 0, 0)
        self.single_path = QLineEdit()
        self.single_path.setPlaceholderText("Select a raster file…")
        self.single_path.textChanged.connect(self._on_input_changed)
        btn_s = _browse_btn()
        btn_s.clicked.connect(self._browse_single)
        sr.addWidget(self.single_path)
        sr.addWidget(btn_s)
        lay.addWidget(self.single_widget)

        # Auto-detect info bar
        self.lbl_source_info = QLabel("")
        self.lbl_source_info.setWordWrap(True)
        self.lbl_source_info.setVisible(False)
        self.lbl_source_info.setStyleSheet(
            "background:#1b3a2e; color:#80CBC4; border-radius:3px;"
            " padding:5px 8px; font-style:italic;")
        lay.addWidget(self.lbl_source_info)

        # Batch
        self.batch_widget = QWidget()
        self.batch_widget.setVisible(False)
        bl = QVBoxLayout(self.batch_widget)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(4)
        btn_row = QHBoxLayout()
        _bs = ("QPushButton { background:#3c3f41 !important; color:#e0e0e0 !important;"
               " border:1px solid #666 !important; border-radius:3px !important; padding:3px 10px !important; }"
               "QPushButton:hover { background:#505050 !important; }")
        self.btn_add_files  = QPushButton("+ Add Files")
        self.btn_add_folder = QPushButton("+ Add Folder")
        self.btn_clear      = QPushButton("Clear")
        for b in (self.btn_add_files, self.btn_add_folder, self.btn_clear):
            b.setFixedHeight(26)
            b.setStyleSheet(_bs)
        self.btn_add_files.clicked.connect(self._add_files)
        self.btn_add_folder.clicked.connect(self._add_folder)
        self.btn_clear.clicked.connect(self._clear_files)
        btn_row.addWidget(self.btn_add_files)
        btn_row.addWidget(self.btn_add_folder)
        btn_row.addWidget(self.btn_clear)
        btn_row.addStretch()
        bl.addLayout(btn_row)
        self.file_list = QListWidget()
        self.file_list.setSelectionMode(_QAV_ExtendedSel)
        self.file_list.setFixedHeight(90)
        bl.addWidget(self.file_list)
        self.lbl_count = QLabel("0 files selected")
        self.lbl_count.setStyleSheet("color:#aaa; font-style:italic;")
        bl.addWidget(self.lbl_count)
        lay.addWidget(self.batch_widget)
        return grp

    # ── Target Resolution ─────────────────────────────────────────────────────
    def _build_resolution_group(self):
        grp = QGroupBox("Resolution")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)

        # ── Grid: Input row + Output row ─────────────────────────────────────
        grid = QGridLayout()
        grid.setSpacing(8)
        grid.setColumnStretch(3, 1)

        # Input resolution (read-only, auto-filled)
        lbl_in = QLabel("Input resolution:")
        lbl_in.setStyleSheet("color:#aaa;")
        grid.addWidget(lbl_in, 0, 0)

        self.spin_in_res = QDoubleSpinBox()
        self.spin_in_res.setRange(0.0, 1_000_000)
        self.spin_in_res.setValue(0.0)
        self.spin_in_res.setDecimals(6)
        self.spin_in_res.setFixedWidth(130)
        self.spin_in_res.setReadOnly(True)
        self.spin_in_res.setStyleSheet(
            "QDoubleSpinBox { background:#2b2b2b !important; color:#aaa !important;"
            " border:1px solid #444 !important; }")
        self.spin_in_res.setButtonSymbols(QDoubleSpinBox.ButtonSymbols.NoButtons
            if hasattr(QDoubleSpinBox, "ButtonSymbols")
            else QDoubleSpinBox.NoButtons)
        grid.addWidget(self.spin_in_res, 0, 1)

        self.lbl_in_unit = QLabel("—")
        self.lbl_in_unit.setStyleSheet(
            "background:#222; color:#aaa; border:1px solid #444;"
            " border-radius:3px; padding:4px 10px;")
        self.lbl_in_unit.setFixedWidth(150)
        grid.addWidget(self.lbl_in_unit, 0, 2)

        lbl_in_hint = QLabel("auto-detected from file")
        lbl_in_hint.setStyleSheet("color:#555; font-style:italic; font-size:12px;")
        grid.addWidget(lbl_in_hint, 0, 3)

        # Separator line
        sep = QFrame()
        sep.setFrameShape(_QFrame_HLine)
        sep.setStyleSheet("color:#444; margin:2px 0;")
        grid.addWidget(sep, 1, 0, 1, 4)

        # Output resolution (editable)
        lbl_out = QLabel("Output resolution:")
        lbl_out.setStyleSheet("color:#e0e0e0; font-weight:bold;")
        grid.addWidget(lbl_out, 2, 0)

        self.spin_res = QDoubleSpinBox()
        self.spin_res.setRange(0.001, 1_000_000)
        self.spin_res.setValue(10.0)
        self.spin_res.setDecimals(6)
        self.spin_res.setFixedWidth(130)
        self.spin_res.valueChanged.connect(self._update_direction_hint)
        grid.addWidget(self.spin_res, 2, 1)

        self.combo_unit = QComboBox()
        for label, _, _ in UNIT_OPTIONS:
            self.combo_unit.addItem(label)
        self.combo_unit.setFixedWidth(150)
        self.combo_unit.currentIndexChanged.connect(self._on_unit_changed)
        grid.addWidget(self.combo_unit, 2, 2)

        lbl_out_hint = QLabel("enter your desired output pixel size")
        lbl_out_hint.setStyleSheet("color:#555; font-style:italic; font-size:12px;")
        grid.addWidget(lbl_out_hint, 2, 3)

        lay.addLayout(grid)

        # Direction hint bar (shown after input file is loaded)
        self.lbl_dir_hint = QLabel("")
        self.lbl_dir_hint.setVisible(False)
        self.lbl_dir_hint.setWordWrap(True)
        self.lbl_dir_hint.setStyleSheet(
            "background:#1e2a35; border-radius:3px; padding:6px 10px; font-style:italic;")
        lay.addWidget(self.lbl_dir_hint)

        # ── Separator + reference raster option ──────────────────────────────
        sep2 = QFrame()
        sep2.setFrameShape(_QFrame_HLine)
        sep2.setStyleSheet("color:#3a3a3a;")
        lay.addWidget(sep2)

        self.rb_ref = QRadioButton("Or match the resolution of a reference raster:")
        self.rb_ref.setStyleSheet("color:#90CAF9;")
        self.rb_ref.toggled.connect(self._toggle_res_mode)
        lay.addWidget(self.rb_ref)

        self.ref_widget = QWidget()
        self.ref_widget.setVisible(False)
        rr = QHBoxLayout(self.ref_widget)
        rr.setContentsMargins(20, 0, 0, 0)
        rr.setSpacing(8)
        self.ref_path = QLineEdit()
        self.ref_path.setPlaceholderText("Select reference raster…")
        btn_ref = _browse_btn()
        btn_ref.clicked.connect(self._browse_ref)
        rr.addWidget(self.ref_path)
        rr.addWidget(btn_ref)
        self.lbl_detected = QLabel("")
        self.lbl_detected.setStyleSheet("color:#4CAF50; font-style:italic;")
        rr.addWidget(self.lbl_detected)
        lay.addWidget(self.ref_widget)

        # hidden radio for custom (always on unless ref selected)
        self.rb_custom = QRadioButton()
        self.rb_custom.setChecked(True)
        self.rb_custom.setVisible(False)

        return grp

    # ── Operation + Method ────────────────────────────────────────────────────
    def _build_operation_group(self):
        grp = QGroupBox("Operation & Resampling Method")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)

        step1 = QLabel("Step 1 — What are you doing?")
        step1.setStyleSheet("color:#90CAF9; font-weight:bold;")
        lay.addWidget(step1)

        op_row = QHBoxLayout()
        op_row.setSpacing(4)
        self.rb_op_up   = QRadioButton()
        self.rb_op_down = QRadioButton()
        self.rb_op_up.setChecked(True)
        lbl_up   = QLabel("Upscaling  (fine → coarse, e.g. 10 m → 500 m)")
        lbl_down = QLabel("Downscaling  (coarse → fine, e.g. 500 m → 10 m)")
        lbl_up.setStyleSheet("color:#90CAF9;")
        lbl_down.setStyleSheet("color:#FFCC80;")
        lbl_up.mousePressEvent   = lambda _e: self.rb_op_up.setChecked(True)
        lbl_down.mousePressEvent = lambda _e: self.rb_op_down.setChecked(True)
        op_row.addWidget(self.rb_op_up)
        op_row.addWidget(lbl_up)
        op_row.addSpacing(20)
        op_row.addWidget(self.rb_op_down)
        op_row.addWidget(lbl_down)
        op_row.addStretch()
        lay.addLayout(op_row)

        self.lbl_op_hint = QLabel("")
        self.lbl_op_hint.setWordWrap(True)
        self.lbl_op_hint.setStyleSheet(
            "background:#1e2a35; color:#90CAF9; border-radius:3px; padding:6px 8px; font-style:italic;")
        lay.addWidget(self.lbl_op_hint)

        self.rb_op_up.toggled.connect(self._refresh_method_combo)

        sep = QFrame()
        sep.setFrameShape(_QFrame_HLine)
        sep.setStyleSheet("color:#444;")
        lay.addWidget(sep)

        step2 = QLabel("Step 2 — Choose a resampling method:")
        step2.setStyleSheet("color:#90CAF9; font-weight:bold;")
        lay.addWidget(step2)

        self.combo_method = QComboBox()
        self.combo_method.setMinimumHeight(28)
        self.combo_method.currentIndexChanged.connect(self._on_method_changed)
        lay.addWidget(self.combo_method)

        badge_row = QHBoxLayout()
        self.lbl_engine_badge = QLabel("")
        self.lbl_dir_badge    = QLabel("")
        self.lbl_engine_badge.setFixedWidth(120)
        self.lbl_engine_badge.setAlignment(_Qt_AlignCenter)
        self.lbl_dir_badge.setAlignment(_Qt_AlignCenter)
        badge_row.addWidget(self.lbl_engine_badge)
        badge_row.addSpacing(6)
        badge_row.addWidget(self.lbl_dir_badge)
        badge_row.addStretch()
        lay.addLayout(badge_row)

        self.lbl_method_hint = QLabel("")
        self.lbl_method_hint.setWordWrap(True)
        self.lbl_method_hint.setStyleSheet(
            "background:#1e2a35; color:#ccc; border-radius:3px; padding:6px 8px; font-style:italic;")
        lay.addWidget(self.lbl_method_hint)

        self._refresh_method_combo()
        return grp

    # ── Nodata ────────────────────────────────────────────────────────────────
    def _build_nodata_group(self):
        grp = QGroupBox("Nodata Value")
        lay = QHBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        self.chk_nodata  = QCheckBox("Override nodata:")
        self.spin_nodata = QDoubleSpinBox()
        self.spin_nodata.setRange(-1e15, 1e15)
        self.spin_nodata.setValue(-9999)
        self.spin_nodata.setEnabled(False)
        self.spin_nodata.setFixedWidth(130)
        self.chk_nodata.toggled.connect(self.spin_nodata.setEnabled)
        hint = QLabel("Leave unchecked to inherit from source")
        hint.setStyleSheet("color:#aaa; font-style:italic;")
        lay.addWidget(self.chk_nodata)
        lay.addWidget(self.spin_nodata)
        lay.addSpacing(10)
        lay.addWidget(hint)
        lay.addStretch()
        return grp

    # ── CRS Converter ─────────────────────────────────────────────────────────
    def _build_crs_group(self):
        grp = QGroupBox("CRS / Projection Converter")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(6)

        self.chk_crs = QCheckBox("Reproject output to a different CRS")
        self.chk_crs.toggled.connect(self._toggle_crs)
        lay.addWidget(self.chk_crs)

        self.crs_widget = QWidget()
        self.crs_widget.setVisible(False)
        crs_lay = QVBoxLayout(self.crs_widget)
        crs_lay.setContentsMargins(20, 4, 0, 0)
        crs_lay.setSpacing(4)

        if _HAS_CRS_WIDGET:
            # Native QGIS CRS picker
            self._crs_selector = QgsProjectionSelectionWidget()
            crs_lay.addWidget(self._crs_selector)
            self._crs_mode = 'widget'
        else:
            # Fallback: EPSG text field
            epsg_row = QHBoxLayout()
            epsg_row.addWidget(QLabel("Target CRS (EPSG):"))
            self._crs_edit = QLineEdit()
            self._crs_edit.setPlaceholderText("e.g. EPSG:4326")
            self._crs_edit.setFixedWidth(200)
            epsg_row.addWidget(self._crs_edit)
            epsg_row.addStretch()
            crs_lay.addLayout(epsg_row)
            self._crs_mode = 'text'

        lay.addWidget(self.crs_widget)
        return grp

    # ── Clip ──────────────────────────────────────────────────────────────────
    def _build_clip_group(self):
        grp = QGroupBox("Clip / Mask")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(6)

        self.chk_clip = QCheckBox("Clip output")
        self.chk_clip.toggled.connect(self._toggle_clip)
        lay.addWidget(self.chk_clip)

        self.clip_body = QWidget()
        self.clip_body.setVisible(False)
        clip_lay = QVBoxLayout(self.clip_body)
        clip_lay.setContentsMargins(20, 4, 0, 4)
        clip_lay.setSpacing(6)

        # Clip type selection
        type_row = QHBoxLayout()
        self.rb_clip_extent = QRadioButton("By extent  (bounding box)")
        self.rb_clip_shp    = QRadioButton("By shapefile  (cutline)")
        self.rb_clip_extent.setChecked(True)
        self.rb_clip_extent.toggled.connect(self._toggle_clip_type)
        type_row.addWidget(self.rb_clip_extent)
        type_row.addSpacing(20)
        type_row.addWidget(self.rb_clip_shp)
        type_row.addStretch()
        clip_lay.addLayout(type_row)

        # ── Extent inputs ────────────────────────────────────────────────────
        self.clip_extent_widget = QWidget()
        ext_lay = QVBoxLayout(self.clip_extent_widget)
        ext_lay.setContentsMargins(0, 0, 0, 0)
        ext_lay.setSpacing(4)

        grid = QGridLayout()
        grid.setSpacing(6)

        def _spin():
            s = QDoubleSpinBox()
            s.setRange(-1e9, 1e9)
            s.setDecimals(6)
            s.setValue(0.0)
            s.setFixedWidth(140)
            return s

        grid.addWidget(QLabel("X min:"),  0, 0)
        self.spin_xmin = _spin()
        grid.addWidget(self.spin_xmin,   0, 1)
        grid.addWidget(QLabel("Y min:"),  0, 2)
        self.spin_ymin = _spin()
        grid.addWidget(self.spin_ymin,   0, 3)
        grid.addWidget(QLabel("X max:"),  1, 0)
        self.spin_xmax = _spin()
        grid.addWidget(self.spin_xmax,   1, 1)
        grid.addWidget(QLabel("Y max:"),  1, 2)
        self.spin_ymax = _spin()
        grid.addWidget(self.spin_ymax,   1, 3)
        ext_lay.addLayout(grid)

        btn_canvas = QPushButton("Use Current Map Canvas Extent")
        btn_canvas.setStyleSheet(
            "QPushButton { background:#1e3a5f !important; color:#90CAF9 !important;"
            " border:1px solid #1565C0 !important; border-radius:3px !important;"
            " padding:4px 12px !important; }"
            "QPushButton:hover { background:#1565C0 !important; color:white !important; }"
        )
        btn_canvas.setFixedHeight(28)
        btn_canvas.clicked.connect(self._use_canvas_extent)
        ext_lay.addWidget(btn_canvas)
        clip_lay.addWidget(self.clip_extent_widget)

        # ── Shapefile input ──────────────────────────────────────────────────
        self.clip_shp_widget = QWidget()
        self.clip_shp_widget.setVisible(False)
        shp_row = QHBoxLayout(self.clip_shp_widget)
        shp_row.setContentsMargins(0, 0, 0, 0)
        self.shp_path = QLineEdit()
        self.shp_path.setPlaceholderText("Select shapefile (.shp)…")
        btn_shp = _browse_btn()
        btn_shp.clicked.connect(self._browse_shapefile)
        shp_row.addWidget(self.shp_path)
        shp_row.addWidget(btn_shp)
        clip_lay.addWidget(self.clip_shp_widget)

        lay.addWidget(self.clip_body)
        return grp

    # ── Output ────────────────────────────────────────────────────────────────
    def _build_output_group(self):
        grp = QGroupBox("Output")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(6)

        self.chk_temp = QCheckBox(
            "Save as temporary file  (auto-added to project, deleted when QGIS closes)")
        self.chk_temp.toggled.connect(self._toggle_temp_mode)
        lay.addWidget(self.chk_temp)

        self.perm_widget = QWidget()
        pl = QVBoxLayout(self.perm_widget)
        pl.setContentsMargins(0, 0, 0, 0)
        pl.setSpacing(4)
        folder_row = QHBoxLayout()
        lbl_f = QLabel("Folder:")
        lbl_f.setFixedWidth(50)
        folder_row.addWidget(lbl_f)
        self.output_folder = QLineEdit()
        self.output_folder.setPlaceholderText("Select output folder…")
        btn_out = _browse_btn()
        btn_out.clicked.connect(self._browse_output)
        folder_row.addWidget(self.output_folder)
        folder_row.addWidget(btn_out)
        pl.addLayout(folder_row)
        suffix_row = QHBoxLayout()
        lbl_s = QLabel("Suffix:")
        lbl_s.setFixedWidth(50)
        suffix_row.addWidget(lbl_s)
        self.edit_suffix = QLineEdit("_resampled")
        self.edit_suffix.setFixedWidth(180)
        suffix_row.addWidget(self.edit_suffix)
        suffix_row.addStretch()
        pl.addLayout(suffix_row)
        lay.addWidget(self.perm_widget)

        self.chk_add_layers = QCheckBox("Add output(s) to QGIS project")
        self.chk_add_layers.setChecked(True)
        lay.addWidget(self.chk_add_layers)
        return grp

    # ── Progress ──────────────────────────────────────────────────────────────
    def _build_progress_group(self):
        grp = QGroupBox("Progress")
        lay = QVBoxLayout(grp)
        lay.setContentsMargins(12, 8, 12, 8)
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.lbl_status = QLabel("Ready")
        lay.addWidget(self.progress_bar)
        lay.addWidget(self.lbl_status)
        return grp

    # ── Run / Cancel ──────────────────────────────────────────────────────────
    def _build_button_row(self):
        row = QHBoxLayout()
        row.setContentsMargins(0, 4, 0, 4)
        self.btn_run    = QPushButton("Run")
        self.btn_cancel = QPushButton("Cancel")
        self.btn_run.setFixedHeight(36)
        self.btn_cancel.setFixedHeight(36)
        self.btn_run.clicked.connect(self._run)
        self.btn_cancel.clicked.connect(self._cancel)
        row.addStretch()
        row.addWidget(self.btn_run)
        row.addSpacing(8)
        row.addWidget(self.btn_cancel)
        return row

    def _style_action_buttons(self):
        self.btn_run.setStyleSheet(
            "QPushButton { background-color:#1565C0 !important; color:white !important;"
            " font-weight:bold !important; padding:6px 28px !important;"
            " border-radius:4px !important; border:none !important; font-size:13px !important; }"
            "QPushButton:hover    { background-color:#1976D2 !important; }"
            "QPushButton:disabled { background-color:#444 !important; color:#777 !important; }"
        )
        self.btn_cancel.setStyleSheet(
            "QPushButton { background-color:#b71c1c !important; color:white !important;"
            " padding:6px 20px !important; border-radius:4px !important;"
            " border:none !important; font-size:13px !important; }"
            "QPushButton:hover { background-color:#c62828 !important; }"
        )

    # =========================================================================
    # TAB 2 — Methods Reference
    # =========================================================================

    def _build_reference_tab(self):
        w   = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        info = QLabel(
            "<b>Upscaling &amp; Downscaling Methods — Reference</b><br>"
            "Methods marked <span style='color:#4CAF50;'>&#10004; Available</span> "
            "can be run in this plugin."
        )
        info.setWordWrap(True)
        info.setTextFormat(_Qt_RichText)
        info.setStyleSheet(
            "padding:8px; border:1px solid #555; border-radius:4px;"
            " background:#1e2a35; color:#e0e0e0;")
        lay.addWidget(info)

        fr = QHBoxLayout()
        fr.addWidget(QLabel("Filter:"))
        self.combo_filter = QComboBox()
        self.combo_filter.addItems([
            "All Methods", "Upscaling Only", "Downscaling Only",
            "Available in Plugin"])
        self.combo_filter.setFixedWidth(220)
        self.combo_filter.currentIndexChanged.connect(self._filter_table)
        fr.addWidget(self.combo_filter)
        _available_count = sum(1 for m in ALL_METHODS_REFERENCE if m[7])
        lbl_total = QLabel(f"  Total: {_available_count} methods")
        lbl_total.setStyleSheet("color:#aaa; font-style:italic;")
        fr.addWidget(lbl_total)
        fr.addStretch()
        lay.addLayout(fr)

        cols = ["Category", "Method", "Type", "Principle",
                "Best For", "Advantages", "Limitations"]
        self.ref_table = QTableWidget(0, len(cols))
        self.ref_table.setHorizontalHeaderLabels(cols)
        self.ref_table.horizontalHeader().setSectionResizeMode(_QHV_ResizeContents)
        self.ref_table.setEditTriggers(_QAV_NoEdit)
        self.ref_table.setSelectionBehavior(_QAV_SelectRows)
        self.ref_table.setAlternatingRowColors(True)
        self.ref_table.verticalHeader().setVisible(False)
        self.ref_table.setShowGrid(True)
        self.ref_table.setWordWrap(True)
        self.ref_table.setSortingEnabled(True)
        lay.addWidget(self.ref_table)
        self._populate_table([m for m in ALL_METHODS_REFERENCE if m[7]])
        return w

    def _populate_table(self, rows):
        self.ref_table.setSortingEnabled(False)
        self.ref_table.setRowCount(0)
        for row_data in rows:
            cat, name, type_, principle, best_for, adv, lim, available = row_data
            r = self.ref_table.rowCount()
            self.ref_table.insertRow(r)
            for c, text in enumerate([cat, name, type_, principle, best_for, adv, lim]):
                item = QTableWidgetItem(str(text))
                item.setFlags(_Qt_ItemSelectable | _Qt_ItemEnabled)
                item.setForeground(
                    QColor("#90CAF9") if (c == 0 and cat == "Upscaling")
                    else QColor("#FFCC80") if (c == 0)
                    else QColor("#e0e0e0"))
                self.ref_table.setItem(r, c, item)
        self.ref_table.resizeRowsToContents()
        self.ref_table.setSortingEnabled(True)

    def _filter_table(self):
        label = self.combo_filter.currentText()
        available = [m for m in ALL_METHODS_REFERENCE if m[7]]
        if label == "Upscaling Only":
            data = [m for m in available if m[0] == "Upscaling"]
        elif label == "Downscaling Only":
            data = [m for m in available if m[0] == "Downscaling"]
        elif label == "Available in Plugin":
            data = available
        else:
            data = available
        self._populate_table(data)


    # =========================================================================
    # Auto-detect source resolution
    # =========================================================================

    def _on_input_changed(self, path):
        path = path.strip()
        if not path or not os.path.exists(path):
            self.lbl_source_info.setVisible(False)
            self.lbl_dir_hint.setVisible(False)
            self._source_x_res  = None
            self._source_y_res  = None
            self._source_is_geo = False
            self._source_unit   = "m"
            return
        try:
            from .resampler import get_raster_info
            from osgeo import osr
            info = get_raster_info(path)
            xr = info['x_res']
            yr = info['y_res']
            self._source_x_res  = xr
            self._source_y_res  = yr
            self._source_is_geo = False
            self._source_unit   = "m"

            if info['crs_wkt']:
                try:
                    srs = osr.SpatialReference()
                    srs.ImportFromWkt(info['crs_wkt'])
                    if srs.IsGeographic():
                        self._source_is_geo = True
                        self._source_unit   = "\u00b0"   # degree sign
                    else:
                        uname = (srs.GetLinearUnitsName() or "m").lower()
                        self._source_unit = uname[:3]
                except Exception:
                    pass

            crs_label = ""
            if _HAS_CRS_CORE and info['crs_wkt']:
                try:
                    crs = QgsCoordinateReferenceSystem()
                    crs.createFromWkt(info['crs_wkt'])
                    if crs.isValid():
                        crs_label = f"  |  CRS: {crs.authid()}"
                except Exception:
                    pass

            u = self._source_unit
            w = info['width']
            h = info['height']
            b = info['band_count']
            self.lbl_source_info.setText(
                f"Source:  {xr:.6g} {u}  ×  {yr:.6g} {u}"
                f"  |  {w} × {h} px  |  {b} band(s){crs_label}"
            )
            self.lbl_source_info.setVisible(True)
            # Fill input resolution row
            self.spin_in_res.setValue(xr)
            unit_label = f"{xr:.6g} {u} / pixel"
            self.lbl_in_unit.setText(f"{u} — {'degrees' if u == chr(176) else 'metres' if u == 'm' else u}")
            # Set output resolution spinbox to same unit as source
            if u == chr(176):  # degrees
                idx = next((i for i, (_, code, _) in enumerate(UNIT_OPTIONS) if code == "deg"), 0)
            else:
                idx = next((i for i, (_, code, _) in enumerate(UNIT_OPTIONS) if code == "m"), 0)
            self.combo_unit.setCurrentIndex(idx)
            self._prev_unit_idx = idx
            # Pre-fill output with source value so user sees where they're starting
            self.spin_res.setValue(xr)
            self._update_direction_hint()
        except Exception as e:
            self.lbl_source_info.setText(f"Could not read raster: {e}")
            self.lbl_source_info.setVisible(True)

    # Degree ↔ metre approximation: 1° ≈ 111,111 m at the equator
    _DEG_TO_M = 111_111.0

    def _on_unit_changed(self, new_idx):
        """Convert the current output value when the unit dropdown changes."""
        prev_idx = self._prev_unit_idx
        if new_idx == prev_idx:
            return

        _, prev_code, prev_mul = UNIT_OPTIONS[prev_idx]
        _, new_code,  new_mul  = UNIT_OPTIONS[new_idx]

        current_val = self.spin_res.value()

        # Convert via metres as the common intermediate unit.
        # Degree ↔ metre uses 1° ≈ 111,111 m (equator approximation).
        if prev_code == "deg":
            val_in_m = current_val * self._DEG_TO_M
        else:
            val_in_m = current_val * prev_mul          # to metres

        if new_code == "deg":
            converted = val_in_m / self._DEG_TO_M
        else:
            converted = val_in_m / new_mul             # from metres

        self._prev_unit_idx = new_idx
        self.spin_res.blockSignals(True)
        self.spin_res.setValue(round(converted, 6))
        self.spin_res.blockSignals(False)
        self._update_direction_hint()

    def _update_direction_hint(self):
        if self._source_x_res is None:
            self.lbl_dir_hint.setVisible(False)
            return

        src      = self._source_x_res
        src_unit = getattr(self, "_source_unit", "m")
        is_geo   = getattr(self, "_source_is_geo", False)
        _, code, mul = UNIT_OPTIONS[self.combo_unit.currentIndex()]
        target_raw   = self.spin_res.value()
        target_m     = target_raw * mul
        target_label = f"{target_raw:.6g} {code}"

        # Unit mismatch warning
        target_is_deg = (code == "deg")
        if is_geo and not target_is_deg:
            self.lbl_dir_hint.setText(
                f"\u26a0  Source CRS is geographic (resolution in degrees: {src:.6g}\u00b0) "
                f"but target unit is {code}.\n"
                f"These cannot be meaningfully compared. "
                f"Enter target in degrees (\u00b0 unit), "
                f"or reproject to a projected CRS first using the CRS Converter below."
            )
            self.lbl_dir_hint.setStyleSheet(
                "background:#3b2000; color:#FFB74D; border-radius:3px;"
                " padding:7px 10px; margin-left:20px;")
            self.lbl_dir_hint.setVisible(True)
            return
        if not is_geo and target_is_deg:
            self.lbl_dir_hint.setText(
                f"\u26a0  Source CRS is projected (resolution in metres: {src:.6g} m) "
                f"but target unit is degrees (\u00b0).\n"
                f"Switch the unit to metres (m) to match your source raster."
            )
            self.lbl_dir_hint.setStyleSheet(
                "background:#3b2000; color:#FFB74D; border-radius:3px;"
                " padding:7px 10px; margin-left:20px;")
            self.lbl_dir_hint.setVisible(True)
            return

        # Same unit — safe to compare
        if abs(target_m - src) < src * 0.001:
            self.lbl_dir_hint.setText(
                f"Target \u2248 source ({src:.6g} {src_unit}). "
                f"No resolution change — output will match input pixel size.")
            self.lbl_dir_hint.setStyleSheet(
                "background:#2b2a15; color:#FFCC80; border-radius:3px;"
                " padding:6px 10px; font-style:italic; margin-left:20px;")
        elif target_m > src:
            factor = round(target_m / src, 1)
            self.lbl_dir_hint.setText(
                f"Source: {src:.6g} {src_unit}  \u2192  Target: {target_label}\n"
                f"Pixel size increases {factor}\u00d7 \u2014 "
                f"Upscaling (fine \u2192 coarse, aggregation).\n"
                f"Recommended methods: Mean, Mode, Max, Median, Sum."
            )
            self.lbl_dir_hint.setStyleSheet(
                "background:#1b3a2e; color:#80CBC4; border-radius:3px;"
                " padding:6px 10px; font-style:italic; margin-left:20px;")
            self.rb_op_up.setChecked(True)
        else:
            factor = round(src / target_m, 1)
            self.lbl_dir_hint.setText(
                f"Source: {src:.6g} {src_unit}  \u2192  Target: {target_label}\n"
                f"Pixel size decreases {factor}\u00d7 \u2014 "
                f"Downscaling (coarse \u2192 fine, interpolation).\n"
                f"Recommended methods: Bilinear, Cubic, Lanczos, Spline."
            )
            self.lbl_dir_hint.setStyleSheet(
                "background:#2b2a15; color:#FFCC80; border-radius:3px;"
                " padding:6px 10px; font-style:italic; margin-left:20px;")
            self.rb_op_down.setChecked(True)
        self.lbl_dir_hint.setVisible(True)


    # =========================================================================
    # Toggle helpers
    # =========================================================================

    def _toggle_mode(self):
        batch = self.rb_batch.isChecked()
        self.single_widget.setVisible(not batch)
        self.lbl_source_info.setVisible(
            not batch and self.lbl_source_info.text() != "")
        self.batch_widget.setVisible(batch)

    def _toggle_res_mode(self):
        use_ref = self.rb_ref.isChecked()
        self.ref_widget.setVisible(use_ref)
        # grey out the output spinbox/unit when using reference raster
        self.spin_res.setEnabled(not use_ref)
        self.combo_unit.setEnabled(not use_ref)

    def _toggle_crs(self, checked):
        self.crs_widget.setVisible(checked)

    def _toggle_clip(self, checked):
        self.clip_body.setVisible(checked)

    def _toggle_clip_type(self):
        extent = self.rb_clip_extent.isChecked()
        self.clip_extent_widget.setVisible(extent)
        self.clip_shp_widget.setVisible(not extent)

    def _toggle_temp_mode(self, checked):
        self.perm_widget.setVisible(not checked)
        if checked:
            self.chk_add_layers.setChecked(True)

    def _refresh_method_combo(self):
        is_up = self.rb_op_up.isChecked()
        mode  = "up" if is_up else "down"

        if is_up:
            self.lbl_op_hint.setText(
                "Upscaling aggregates fine pixels into larger coarser pixels. "
                "Use statistical methods: Mean, Mode, Max, Median, etc.")
            self.lbl_op_hint.setStyleSheet(
                "background:#1e2a35; color:#90CAF9; border-radius:3px; padding:6px 8px; font-style:italic;")
        else:
            self.lbl_op_hint.setText(
                "Downscaling interpolates a coarse raster to a finer resolution. "
                "Use interpolation methods: Bilinear, Cubic, Lanczos, Spline, etc.")
            self.lbl_op_hint.setStyleSheet(
                "background:#1e2a35; color:#FFCC80; border-radius:3px; padding:6px 8px; font-style:italic;")

        self.combo_method.blockSignals(True)
        self.combo_method.clear()

        gdal_m  = [m for m in RESAMPLING_METHODS if m[2] == "GDAL"  and m[3] in (mode, "both")]
        scipy_m = [m for m in RESAMPLING_METHODS if m[2] == "SciPy" and m[3] in (mode, "both")]

        if gdal_m:
            self.combo_method.addItem("── GDAL Native Methods ──")
            self.combo_method.model().item(self.combo_method.count() - 1).setEnabled(False)
            for m in gdal_m:
                self.combo_method.addItem(m[0], m[1])
        if scipy_m:
            self.combo_method.addItem("── Custom SciPy Methods ──")
            self.combo_method.model().item(self.combo_method.count() - 1).setEnabled(False)
            for m in scipy_m:
                self.combo_method.addItem(m[0], m[1])

        self.combo_method.blockSignals(False)
        for i in range(self.combo_method.count()):
            if self.combo_method.itemData(i) is not None:
                self.combo_method.setCurrentIndex(i)
                break
        self._on_method_changed(self.combo_method.currentIndex())

    def _on_method_changed(self, idx):
        code = self.combo_method.itemData(idx)
        if not code:
            return
        for m in RESAMPLING_METHODS:
            if m[1] == code:
                engine, use, desc = m[2], m[3], m[4]
                self.lbl_method_hint.setText(desc)
                self.lbl_engine_badge.setText(f"Engine: {engine}")
                self.lbl_engine_badge.setStyleSheet(
                    "background:#1565C0; color:white; border-radius:3px;"
                    " padding:2px 8px; font-size:12px; font-weight:bold;")
                dl = {"up": "Upscaling", "down": "Downscaling", "both": "Both directions"}
                db = {"up": "#1b3a2e",   "down": "#2b2a15",     "both": "#1a2b3a"}
                df = {"up": "#4CAF50",   "down": "#FFCC80",     "both": "#90CAF9"}
                self.lbl_dir_badge.setText(f"Best for: {dl.get(use, use)}")
                self.lbl_dir_badge.setStyleSheet(
                    f"background:{db.get(use,'#333')}; color:{df.get(use,'#eee')};"
                    " border-radius:3px; padding:2px 8px; font-size:12px; font-weight:bold;")
                return

    # =========================================================================
    # File browsers
    # =========================================================================

    def _browse_single(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Raster", "", RASTER_FILTER)
        if p:
            self.single_path.setText(p)

    def _browse_ref(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Reference Raster", "", RASTER_FILTER)
        if p:
            self.ref_path.setText(p)
            self._detect_resolution(p)

    def _detect_resolution(self, path):
        try:
            ds = gdal.Open(path)
            if ds:
                gt = ds.GetGeoTransform()
                self.lbl_detected.setText(
                    f"Detected: {abs(gt[1]):.5g} × {abs(gt[5]):.5g}")
                ds = None
        except Exception as e:
            self.lbl_detected.setText(f"Could not read: {e}")

    def _browse_output(self):
        p = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if p:
            self.output_folder.setText(p)

    def _browse_shapefile(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select Shapefile", "", SHAPEFILE_FILTER)
        if p:
            self.shp_path.setText(p)

    def _add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Select Raster Files", "", RASTER_FILTER)
        self._append_to_list(paths)

    def _add_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder")
        if not folder:
            return
        paths = []
        for ext in ('*.tif', '*.tiff', '*.img', '*.vrt', '*.nc'):
            paths.extend(glob.glob(os.path.join(folder, ext)))
        self._append_to_list(sorted(paths))

    def _append_to_list(self, paths):
        existing = {self.file_list.item(i).toolTip() for i in range(self.file_list.count())}
        for p in paths:
            if p not in existing:
                item = QListWidgetItem(os.path.basename(p))
                item.setToolTip(p)
                self.file_list.addItem(item)
        self.lbl_count.setText(f"{self.file_list.count()} file(s) selected")

    def _clear_files(self):
        self.file_list.clear()
        self.lbl_count.setText("0 files selected")

    def _use_canvas_extent(self):
        try:
            canvas  = self.iface.mapCanvas()
            extent  = canvas.extent()
            self.spin_xmin.setValue(extent.xMinimum())
            self.spin_ymin.setValue(extent.yMinimum())
            self.spin_xmax.setValue(extent.xMaximum())
            self.spin_ymax.setValue(extent.yMaximum())
        except Exception as e:
            QMessageBox.warning(self, "Canvas Extent",
                                f"Could not read canvas extent:\n{e}")

    # =========================================================================
    # Resolution helper
    # =========================================================================

    def _get_resolution_in_map_units(self):
        value = self.spin_res.value()
        _, _, multiplier = UNIT_OPTIONS[self.combo_unit.currentIndex()]
        return value * multiplier

    def _get_target_crs(self):
        """Return CRS string like 'EPSG:4326' or None."""
        if not self.chk_crs.isChecked():
            return None
        if self._crs_mode == 'widget':
            crs = self._crs_selector.crs()
            return crs.authid() if crs and crs.isValid() else None
        else:
            txt = self._crs_edit.text().strip()
            return txt if txt else None

    # =========================================================================
    # Validation
    # =========================================================================

    def _collect_params(self):
        p = {}
        p['batch'] = self.rb_batch.isChecked()

        if p['batch']:
            files = [self.file_list.item(i).toolTip() for i in range(self.file_list.count())]
            if not files:
                QMessageBox.warning(self, "Input Error", "No files added.")
                return None
            p['files'] = files
        else:
            path = self.single_path.text().strip()
            if not path or not os.path.exists(path):
                QMessageBox.warning(self, "Input Error", "Please select a valid input raster.")
                return None
            p['files'] = [path]

        p['use_ref'] = self.rb_ref.isChecked()
        if p['use_ref']:
            ref = self.ref_path.text().strip()
            if not ref or not os.path.exists(ref):
                QMessageBox.warning(self, "Input Error", "Please select a valid reference raster.")
                return None
            p['ref_path'] = ref
        else:
            p['resolution'] = self._get_resolution_in_map_units()

        p['method'] = self.combo_method.currentData()
        if not p['method']:
            QMessageBox.warning(self, "Method Error", "Please select a resampling method.")
            return None

        p['nodata']     = self.spin_nodata.value() if self.chk_nodata.isChecked() else None
        p['target_crs'] = self._get_target_crs()

        # Clip
        if self.chk_clip.isChecked():
            if self.rb_clip_extent.isChecked():
                xmin = self.spin_xmin.value()
                ymin = self.spin_ymin.value()
                xmax = self.spin_xmax.value()
                ymax = self.spin_ymax.value()
                if xmin >= xmax or ymin >= ymax:
                    QMessageBox.warning(self, "Clip Error",
                                        "Invalid extent: xmin must be < xmax and ymin < ymax.")
                    return None
                p['clip_extent']    = (xmin, ymin, xmax, ymax)
                p['clip_shapefile'] = None
            else:
                shp = self.shp_path.text().strip()
                if not shp or not os.path.exists(shp):
                    QMessageBox.warning(self, "Clip Error",
                                        "Please select a valid shapefile.")
                    return None
                p['clip_extent']    = None
                p['clip_shapefile'] = shp
        else:
            p['clip_extent']    = None
            p['clip_shapefile'] = None

        p['temp_file'] = self.chk_temp.isChecked()
        if p['temp_file']:
            p['output_folder']  = tempfile.gettempdir()
            p['suffix']         = "_resampled_tmp"
            p['add_to_project'] = True
        else:
            out = self.output_folder.text().strip()
            if not out:
                QMessageBox.warning(self, "Output Error", "Please select an output folder.")
                return None
            p['output_folder']  = out
            p['suffix']         = self.edit_suffix.text().strip() or "_resampled"
            p['add_to_project'] = self.chk_add_layers.isChecked()

        return p

    # =========================================================================
    # Run / Cancel / Signals
    # =========================================================================

    def _run(self):
        params = self._collect_params()
        if params is None:
            return
        from .worker import ResampleWorker
        self.thread = QThread()
        self.worker = ResampleWorker(params)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._on_progress)
        self.worker.file_done.connect(self._on_file_done)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.finished.connect(self.thread.quit)
        self.worker.error.connect(self.thread.quit)
        self.btn_run.setEnabled(False)
        self.progress_bar.setValue(0)
        self.lbl_status.setText("Starting…")
        self.thread.start()

    def _cancel(self):
        if self.worker:
            self.worker.stop()
            self.lbl_status.setText("Cancelled")

    def _on_progress(self, pct, msg):
        self.progress_bar.setValue(pct)
        self.lbl_status.setText(msg)

    def _on_file_done(self, output_path):
        if self.chk_add_layers.isChecked():
            from qgis.core import QgsRasterLayer, QgsProject
            name  = os.path.splitext(os.path.basename(output_path))[0]
            layer = QgsRasterLayer(output_path, name)
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)

    def _on_finished(self, output_paths):
        self.btn_run.setEnabled(True)
        self.progress_bar.setValue(100)
        n    = len(output_paths)
        dest = "temp folder" if self.chk_temp.isChecked() else self.output_folder.text()
        self.lbl_status.setText(f"Done — {n} file(s) written.")
        QMessageBox.information(self, "Complete",
                                f"Resampling complete.\n{n} file(s) saved to:\n{dest}")

    def _on_error(self, msg):
        self.btn_run.setEnabled(True)
        self.lbl_status.setText("Error — see message")
        QMessageBox.critical(self, "Error", msg)
